﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {

       
        
        private double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            realizarOperaciones("*");

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            textBox2.Text = "0";

        }

        //método que realiza las operaciones
        private void realizarOperaciones(string operacion)
        {
            Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
            numero1 = Double.Parse(textBox1.Text);
            numero2 = Double.Parse(textBox2.Text);

            if (operacion == "+")
            {
                resultado = numero1 + numero2;
                labelResultado.Text = "El resultado de la suma es: " + resultado.ToString();
            }else if (operacion == "*")
            {
                resultado = numero1 * numero2;
                labelResultado.Text = "El resultado de la multipliación es: " + resultado.ToString();
            }else if (operacion == "/")
            {
                resultado = numero1 / numero2;
                labelResultado.Text = "El resultado de la división es: " + resultado.ToString();
            }else if (operacion == "-")
            {
                resultado = numero1 - numero2;
                labelResultado.Text = "El resultado de la resta es: " + resultado.ToString();
            }    





        }

        private void btSuma_Click(object sender, EventArgs e)
        {
            realizarOperaciones("+");
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            realizarOperaciones("-");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            realizarOperaciones("/");
        }


        //permitir solo entrada de números
        private void textBox1Validacion(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
               (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("Solo se permiten números");
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void textBox2Validacion(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
               (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("Solo se permiten números");
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

        }

       
    }
}
